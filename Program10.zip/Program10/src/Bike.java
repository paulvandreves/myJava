/**
 * Created by Paul on 11/12/2016.
 */
import java.util.*;
public class Bike implements CarbonFootPrint
{

    public double getCarbonFootPrint()
    {
        double carbonFootPrint = 0;
        return carbonFootPrint;

    }

    public Bike()
    {
        System.out.println("Your Biking has a negative impact on your carbon foot print  ");
    }


}
