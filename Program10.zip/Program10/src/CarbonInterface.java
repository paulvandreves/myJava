/**
 * Created by Paul on 11/14/2016.
 */
import java.util.*;
public class CarbonInterface
{

   List<Car> obj = new ArrayList<Car>();








    public static void main(String[] args)
    {
        Car jeep = new Car();

        Building house = new Building();

        Bike foesHydro = new Bike();


    }
}
