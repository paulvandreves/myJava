/**
 * Created by Paul on 11/2/2016.
 */
public interface Payable
{
    double getPaymentAmount();
}
