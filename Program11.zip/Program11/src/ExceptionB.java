/**
 * Created by Paul on 11/15/2016.
 */
public class ExceptionB extends ExceptionA
{
    public ExceptionB(String message)
    {
        super(message);
    }
}
