/**
 * Created by Paul on 10/23/2016.
 */
import java.util.Date;
public class Dates {
    public void main(String[] args)
    {
        Date date = new Date(toString());
        System.out.println(date.toString());
        System.out.println(date.getTime());
        System.out.println(date.getDay());
        System.out.println(date.getDate());

    }


}
